/**
 * background.js — Service worker for the vidIQ Coach Analytics Capture extension.
 * 
 * Handles:
 * - Badge updates from content script
 * - Data export to the coaching report pipeline
 * - Status tracking across multiple channels
 */

// Track capture status per channel
const channelStatus = {};

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === 'update_badge') {
    chrome.action.setBadgeText({ text: message.text, tabId: sender.tab?.id });
    chrome.action.setBadgeBackgroundColor({ color: message.color, tabId: sender.tab?.id });
    return;
  }

  if (message.action === 'capture_update') {
    channelStatus[message.channelId] = {
      channelName: message.channelName,
      captureCount: message.captureCount,
      hasChannelAnalytics: message.hasChannelAnalytics,
      hasVideoList: message.hasVideoList,
      videoAnalyticsCount: message.videoAnalyticsCount,
      lastUpdated: message.lastUpdated
    };
    return;
  }

  if (message.action === 'get_status') {
    sendResponse({ channels: channelStatus });
    return true;
  }

  if (message.action === 'resolve_channel_name') {
    fetch('https://www.youtube.com/oembed?url=https://www.youtube.com/channel/' + message.channelId + '&format=json')
      .then(r => r.json())
      .then(d => sendResponse({ name: d?.author_name || null }))
      .catch(() => sendResponse({ name: null }));
    return true;
  }

  if (message.action === 'export_channel') {
    // Export captured data for a specific channel
    const key = 'vidiq_analytics_' + message.channelId;
    chrome.storage.local.get(key, function (result) {
      const data = result[key];
      if (!data) {
        sendResponse({ success: false, error: 'No data for channel' });
        return;
      }

      // Extract the key metrics we need for the report
      const exported = extractReportData(data);
      sendResponse({ success: true, data: exported });
    });
    return true; // async response
  }

  if (message.action === 'export_all') {
    // Export all captured channels
    chrome.storage.local.get(null, function (items) {
      const allData = {};
      for (const [key, value] of Object.entries(items)) {
        if (key.startsWith('vidiq_analytics_')) {
          const channelId = key.replace('vidiq_analytics_', '');
          allData[channelId] = extractReportData(value);
        }
      }
      sendResponse({ success: true, channels: allData });
    });
    return true;
  }
});

/**
 * Extract the specific metrics we need from the raw YouTube Studio API responses.
 * This is where we parse YouTube's internal data format into our report schema.
 */
function extractReportData(rawData) {
  const result = {
    channelId: rawData.channelId,
    channelName: rawData.channelName || null,
    capturedAt: rawData.lastUpdated,
    captureCount: rawData.captureCount,
    channel: {},
    videos: [],
    _rawTypes: {
      hasChannelAnalytics: !!rawData.channelAnalytics,
      hasVideoList: !!rawData.videoList,
      videoAnalyticsCount: rawData.videoAnalytics?.length || 0,
      screenDataCount: rawData.screenData?.length || 0
    }
  };

  if (rawData.channelAnalytics) {
    result.channel._raw = rawData.channelAnalytics;
  }
  if (rawData.analyticsResponses?.length) {
    result.channel._additionalRaw = rawData.analyticsResponses;
  }
  if (rawData.channelMeta) {
    result.channelMeta = rawData.channelMeta;
  }
  if (rawData.videoList) {
    result.videos_raw = rawData.videoList;
  }
  if (rawData.videoAnalytics?.length) {
    result.videoAnalytics_raw = rawData.videoAnalytics.map(va => ({
      url: va.url,
      data: va.data,
      capturedAt: va.capturedAt
    }));
  }
  if (rawData.screenData?.length) {
    result.screenData_raw = rawData.screenData.map(sd => ({
      type: sd.type,
      data: sd.data,
      capturedAt: sd.capturedAt
    }));
  }
  if (rawData.otherCaptures?.length) {
    result.otherCaptures = rawData.otherCaptures;
  }

  return result;
}
