/**
 * content.js — Content script running in YouTube Studio pages.
 * 
 * 1. Injects interceptor.js into the page context to capture API responses.
 * 2. Listens for captured data via window.postMessage.
 * 3. Extracts channel ID from the page URL.
 * 4. Stores captured data in chrome.storage.local keyed by channel ID.
 * 5. Sends status updates to the background service worker.
 */
(function () {
  'use strict';

  // --- Inject the network interceptor into the page context ---
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('interceptor.js');
  script.onload = function () { this.remove(); };
  (document.head || document.documentElement).appendChild(script);

  // --- Extract channel ID from URL ---
  // YouTube Studio URLs: studio.youtube.com/channel/UC.../analytics
  function getChannelId() {
    const match = window.location.pathname.match(/\/channel\/(UC[a-zA-Z0-9_-]+)/);
    return match ? match[1] : null;
  }

  // --- Extract channel name from Studio page DOM ---
  function getChannelName() {
    // YouTube Studio shows the channel name in the header/account switcher
    // Try several selectors that YouTube Studio uses
    const selectors = [
      '#channel-title',
      '.channel-name',
      'ytcp-account-settings .channel-name',
      '#account-name',
      '.ytcp-channel-switcher-item-info .channel-name',
      'yt-formatted-string.ytcd-channel-name',
      '[class*="channel-name"]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent.trim()) return el.textContent.trim();
    }
    // Fallback: parse the page title
    // Formats: "Analytics - ChannelName - YouTube Studio" or "ChannelName - YouTube Studio"
    const title = document.title || '';
    const parts = title.split(' - ').map(p => p.trim());
    const skip = ['YouTube Studio', 'Analytics', 'Content', 'Dashboard', 'Channel dashboard', 'Comments', 'Subtitles', 'Earn', 'Customization'];
    for (const part of parts) {
      if (part && !skip.includes(part) && part.length > 1 && part.length < 80) {
        return part;
      }
    }
    return null;
  }

  // --- Extract channel name from YouTube API response JSON ---
  function extractChannelNameFromResponse(data) {
    if (!data || typeof data !== 'object') return null;
    // Priority 1: Look specifically for channelTitle (not generic title which catches video titles)
    const channelOnlyKeys = ['channelTitle', 'channelName', 'ownerChannelName'];
    function searchChannelKeys(obj, depth) {
      if (depth > 6 || !obj || typeof obj !== 'object') return null;
      for (const key of channelOnlyKeys) {
        if (obj[key] && typeof obj[key] === 'string') {
          const val = obj[key].trim();
          if (val.length > 1 && val.length < 80) return val;
        }
      }
      for (const [k, v] of Object.entries(obj)) {
        if (Array.isArray(v)) {
          for (let i = 0; i < Math.min(v.length, 3); i++) {
            const found = searchChannelKeys(v[i], depth + 1);
            if (found) return found;
          }
        } else if (typeof v === 'object' && v !== null) {
          const found = searchChannelKeys(v, depth + 1);
          if (found) return found;
        }
      }
      return null;
    }
    return searchChannelKeys(data, 0);
  }

  // --- Storage helper ---
  const STORAGE_KEY_PREFIX = 'vidiq_analytics_';

  function getStorageKey(channelId) {
    return STORAGE_KEY_PREFIX + channelId;
  }

  // --- Data accumulator ---
  // We accumulate all captured API responses for this channel in one session
  let capturedData = {
    channelId: null,
    channelName: null,
    channelAnalytics: null,
    videoAnalytics: [],
    videoList: null,
    screenData: [],
    lastUpdated: null,
    captureCount: 0
  };

  // --- Listen for intercepted API data ---
  window.addEventListener('message', function (event) {
    if (event.data?.source !== 'vidiq-coach-capture') return;

    const channelId = getChannelId();
    if (!channelId) return;

    capturedData.channelId = channelId;
    capturedData.lastUpdated = event.data.capturedAt;
    capturedData.captureCount++;

    // Try to get channel name (async lookup if needed)
    if (!capturedData.channelName || capturedData.channelName === 'Channel dashboard') {
      // First try DOM
      var domName = getChannelName();
      if (domName) {
        capturedData.channelName = domName;
      } else if (channelId && !capturedData._nameLookupDone) {
        // Fetch from YouTube's public oembed (no API key needed)
        capturedData._nameLookupDone = true;
        fetch('https://www.youtube.com/oembed?url=https://www.youtube.com/channel/' + channelId + '&format=json')
          .then(function(r) { return r.json(); })
          .then(function(d) {
            if (d && d.author_name) {
              capturedData.channelName = d.author_name;
              var key = getStorageKey(channelId);
              chrome.storage.local.set({ [key]: capturedData });
              chrome.runtime.sendMessage({
                action: 'capture_update',
                channelId: channelId,
                channelName: d.author_name,
                captureCount: capturedData.captureCount,
                hasChannelAnalytics: !!capturedData.channelAnalytics,
                hasVideoList: !!capturedData.videoList,
                videoAnalyticsCount: capturedData.videoAnalytics.length,
                lastUpdated: capturedData.lastUpdated
              });
            }
          })
          .catch(function() {});
      }
    }

    switch (event.data.type) {
      case 'channel_analytics':
        // Accumulate — multiple analytics calls fire on the Overview tab
        if (!capturedData.channelAnalytics) {
          capturedData.channelAnalytics = event.data.data;
        } else {
          // Merge: store latest as primary, keep all in array
          if (!capturedData.analyticsResponses) capturedData.analyticsResponses = [];
          capturedData.analyticsResponses.push(event.data.data);
        }
        break;
      case 'video_analytics':
        const existing = capturedData.videoAnalytics.findIndex(
          v => v.url === event.data.url
        );
        if (existing >= 0) {
          capturedData.videoAnalytics[existing] = event.data;
        } else {
          capturedData.videoAnalytics.push(event.data);
        }
        break;
      case 'video_list':
        capturedData.videoList = event.data.data;
        break;
      case 'channel_meta':
        capturedData.channelMeta = event.data.data;
        break;
      case 'screen_data':
        capturedData.screenData.push(event.data);
        break;
      default:
        // Store all other captures for analysis
        if (!capturedData.otherCaptures) capturedData.otherCaptures = [];
        capturedData.otherCaptures.push({
          type: event.data.type,
          url: event.data.url ? event.data.url.split('?')[0] : 'unknown',
          capturedAt: event.data.capturedAt
        });
        break;
    }

    // Persist to chrome.storage.local
    const key = getStorageKey(channelId);
    chrome.storage.local.set({ [key]: capturedData });

    // Notify the background worker + popup
    chrome.runtime.sendMessage({
      action: 'capture_update',
      channelId: channelId,
      channelName: capturedData.channelName,
      captureCount: capturedData.captureCount,
      hasChannelAnalytics: !!capturedData.channelAnalytics,
      hasVideoList: !!capturedData.videoList,
      videoAnalyticsCount: capturedData.videoAnalytics.length,
      lastUpdated: capturedData.lastUpdated
    });

    // Update the badge
    updateBadge(capturedData);
  });

  function updateBadge(data) {
    const count = data.captureCount;
    chrome.runtime.sendMessage({
      action: 'update_badge',
      text: count > 0 ? String(count) : '',
      color: data.hasChannelAnalytics ? '#00b257' : '#f2b900'
    });
  }

  // --- On page load, check if we already have data for this channel ---
  const channelId = getChannelId();
  if (channelId) {
    const key = getStorageKey(channelId);
    chrome.storage.local.get(key, function (result) {
      if (result[key]) {
        capturedData = result[key];
        console.log(`[vidIQ Coach Capture] Loaded existing data for ${channelId}: ${capturedData.captureCount} captures`);
      }
    });
    console.log(`[vidIQ Coach Capture] Active on channel ${channelId}`);
  }
})();
