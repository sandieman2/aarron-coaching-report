/**
 * interceptor.js — Injected into the page context to intercept YouTube Studio
 * internal API responses (fetch/XHR). Runs in the PAGE's JS context, not the
 * extension's content script context.
 *
 * Captures analytics data from YouTube's internal youtubei/v1 API calls and
 * posts them back to the content script via window.postMessage.
 */
(function () {
  'use strict';

  // Capture ALL youtubei API calls, classify after
  const CAPTURE_PATTERNS = [
    // Catch everything under the youtubei internal API
    { pattern: '/youtubei/v1/', type: 'auto' },
  ];

  // Classify the captured URL into a meaningful type
  function classifyUrl(url) {
    if (url.includes('analytics_data')) return 'channel_analytics';
    if (url.includes('get_screen')) return 'channel_analytics';
    if (url.includes('list_creator_videos')) return 'video_list';
    if (url.includes('get_creator_channels')) return 'channel_meta';
    if (url.includes('get_creator_playlists')) return 'channel_meta';
    if (url.includes('/analytics/')) return 'channel_analytics';
    return 'other';
  }

  function matchPattern(url) {
    for (const p of CAPTURE_PATTERNS) {
      if (url.includes(p.pattern)) return p;
    }
    return null;
  }

  // --- Intercept fetch() ---
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await originalFetch.apply(this, args);
    const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
    const match = matchPattern(url);

    if (match) {
      try {
        const clone = response.clone();
        const body = await clone.json();
        const classifiedType = classifyUrl(url);
        console.log('[vidIQ Coach] Captured', classifiedType, ':', url.split('?')[0]);
        window.postMessage({
          source: 'vidiq-coach-capture',
          type: classifiedType,
          url: url,
          data: body,
          capturedAt: new Date().toISOString()
        }, '*');
      } catch (e) {
        // Silently skip non-JSON or failed reads
      }
    }

    return response;
  };

  // --- Intercept XMLHttpRequest ---
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._vidiqUrl = url;
    this._vidiqMatch = matchPattern(url);
    return originalXHROpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    if (this._vidiqMatch) {
      this.addEventListener('load', function () {
        try {
          const body = JSON.parse(this.responseText);
          const classifiedType = classifyUrl(this._vidiqUrl);
          console.log('[vidIQ Coach] XHR Captured', classifiedType, ':', this._vidiqUrl.split('?')[0]);
          window.postMessage({
            source: 'vidiq-coach-capture',
            type: classifiedType,
            url: this._vidiqUrl,
            data: body,
            capturedAt: new Date().toISOString()
          }, '*');
        } catch (e) {
          // Skip
        }
      });
    }
    return originalXHRSend.apply(this, args);
  };

  console.log('[vidIQ Coach Capture] Network interceptor active');
})();
