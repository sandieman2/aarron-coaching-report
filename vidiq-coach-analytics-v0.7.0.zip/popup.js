/**
 * popup.js — Popup UI logic for the vidIQ Coach Analytics extension.
 */

document.addEventListener('DOMContentLoaded', function () {
  // Show version
  const manifest = chrome.runtime.getManifest();
  document.getElementById('versionLabel').textContent = 'v' + manifest.version;

  loadChannels();

  document.getElementById('exportBtn').addEventListener('click', exportAll);
  document.getElementById('clearBtn').addEventListener('click', clearAll);
});

function loadChannels() {
  chrome.storage.local.get(null, function (items) {
    const channelList = document.getElementById('channelList');
    const exportBtn = document.getElementById('exportBtn');
    const clearBtn = document.getElementById('clearBtn');
    const channels = [];

    for (const [key, value] of Object.entries(items)) {
      if (key.startsWith('vidiq_analytics_')) {
        channels.push(value);
      }
    }

    if (channels.length === 0) {
      channelList.innerHTML = `
        <div class="empty-state">
          <div class="icon">📊</div>
          Navigate to a creator's YouTube Studio Analytics page.<br>
          The extension will automatically capture their data.
        </div>`;
      exportBtn.style.display = 'none';
      clearBtn.style.display = 'none';
      return;
    }

    exportBtn.style.display = 'block';
    clearBtn.style.display = 'block';

    channelList.innerHTML = channels.map(ch => {
      // Ready = we captured at least one API response
      const count = ch.captureCount || 0;
      const isReady = count >= 1;
      const statusClass = isReady ? 'fresh' : 'partial';
      const statusText = isReady ? '✅ ' + count + ' captured' : '⏳ Waiting...';
      const updated = ch.lastUpdated
        ? new Date(ch.lastUpdated).toLocaleDateString()
        : 'Unknown';
      // Channel name: try stored name, fall back to ID
      const rawName = ch.channelName;
      // Filter out generic Studio page titles
      const genericTitles = ['channel dashboard', 'youtube studio', 'analytics', ''];
      const isGenericName = !rawName || genericTitles.includes(rawName.toLowerCase().trim());
      const displayName = isGenericName ? (ch.channelId || 'Unknown') : rawName;
      const subtitle = isGenericName
        ? `${count} captures · ${updated}`
        : `${ch.channelId} · ${count} captures · ${updated}`;

      return `
        <div class="channel-row">
          <div>
            <div class="channel-id">${displayName}</div>
            <div class="capture-count">${subtitle}</div>
          </div>
          <span class="channel-status ${statusClass}">${statusText}</span>
        </div>`;
    }).join('');
  });
}

function exportAll() {
  chrome.runtime.sendMessage({ action: 'export_all' }, function (response) {
    if (!response?.success) {
      alert('Export failed: ' + (response?.error || 'Unknown error'));
      return;
    }

    // Download as JSON
    const blob = new Blob(
      [JSON.stringify(response.channels, null, 2)],
      { type: 'application/json' }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vidiq-coach-analytics-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });
}

function clearAll() {
  if (!confirm('Clear all captured analytics data? This cannot be undone.')) return;
  chrome.storage.local.get(null, function (items) {
    const keys = Object.keys(items).filter(k => k.startsWith('vidiq_analytics_'));
    chrome.storage.local.remove(keys, function () {
      loadChannels();
    });
  });
}
