/**
 * background.js — Service worker for the vidIQ Coach Analytics Capture extension.
 * 
 * Handles:
 * - Badge updates from content script
 * - Data export to the coaching report pipeline
 * - Status tracking across multiple channels
 */

// Track capture status per channel
const channelStatus = {};

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === 'update_badge') {
    chrome.action.setBadgeText({ text: message.text, tabId: sender.tab?.id });
    chrome.action.setBadgeBackgroundColor({ color: message.color, tabId: sender.tab?.id });
    return;
  }

  if (message.action === 'capture_update') {
    channelStatus[message.channelId] = {
      captureCount: message.captureCount,
      hasChannelAnalytics: message.hasChannelAnalytics,
      hasVideoList: message.hasVideoList,
      videoAnalyticsCount: message.videoAnalyticsCount,
      lastUpdated: message.lastUpdated
    };
    return;
  }

  if (message.action === 'get_status') {
    sendResponse({ channels: channelStatus });
    return true;
  }

  if (message.action === 'export_channel') {
    // Export captured data for a specific channel
    const key = 'vidiq_analytics_' + message.channelId;
    chrome.storage.local.get(key, function (result) {
      const data = result[key];
      if (!data) {
        sendResponse({ success: false, error: 'No data for channel' });
        return;
      }

      // Extract the key metrics we need for the report
      const exported = extractReportData(data);
      sendResponse({ success: true, data: exported });
    });
    return true; // async response
  }

  if (message.action === 'export_all') {
    // Export all captured channels
    chrome.storage.local.get(null, function (items) {
      const allData = {};
      for (const [key, value] of Object.entries(items)) {
        if (key.startsWith('vidiq_analytics_')) {
          const channelId = key.replace('vidiq_analytics_', '');
          allData[channelId] = extractReportData(value);
        }
      }
      sendResponse({ success: true, channels: allData });
    });
    return true;
  }
});

/**
 * Extract the specific metrics we need from the raw YouTube Studio API responses.
 * This is where we parse YouTube's internal data format into our report schema.
 */
function extractReportData(rawData) {
  const result = {
    channelId: rawData.channelId,
    capturedAt: rawData.lastUpdated,
    captureCount: rawData.captureCount,

    // Channel-level metrics (from channel_analytics)
    channel: {
      totalWatchTimeHours: null,
      totalImpressions: null,
      overallCTR: null,
      totalViews: null,
      subscribersGained: null,
      subscribersLost: null,
      averageViewDuration: null
    },

    // Per-video metrics (from video_analytics + video_list)
    videos: [],

    // Raw data reference (for debugging / future extraction)
    _rawTypes: {
      hasChannelAnalytics: !!rawData.channelAnalytics,
      hasVideoList: !!rawData.videoList,
      videoAnalyticsCount: rawData.videoAnalytics?.length || 0,
      screenDataCount: rawData.screenData?.length || 0
    }
  };

  // Parse channel analytics
  // YouTube's internal API format varies, so this is defensive parsing
  if (rawData.channelAnalytics) {
    try {
      const ca = rawData.channelAnalytics;
      // The structure is typically: { results: [{ dimensionValues: [...], metricValues: [...] }] }
      // or nested under cardData / dataRows depending on the endpoint
      // We'll store the raw response and parse it in the pipeline where we can iterate
      result.channel._raw = ca;
    } catch (e) {
      result.channel._parseError = e.message;
    }
  }

  // Parse video list
  if (rawData.videoList) {
    try {
      const vl = rawData.videoList;
      // Store raw for pipeline parsing
      result.videos_raw = vl;
    } catch (e) {
      result._videoListParseError = e.message;
    }
  }

  // Include video-level analytics
  if (rawData.videoAnalytics?.length) {
    result.videoAnalytics_raw = rawData.videoAnalytics.map(va => ({
      url: va.url,
      data: va.data,
      capturedAt: va.capturedAt
    }));
  }

  // Include screen/retention data
  if (rawData.screenData?.length) {
    result.screenData_raw = rawData.screenData.map(sd => ({
      type: sd.type,
      data: sd.data,
      capturedAt: sd.capturedAt
    }));
  }

  return result;
}
