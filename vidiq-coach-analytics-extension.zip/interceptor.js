/**
 * interceptor.js — Injected into the page context to intercept YouTube Studio
 * internal API responses (fetch/XHR). Runs in the PAGE's JS context, not the
 * extension's content script context.
 *
 * Captures analytics data from YouTube's internal youtubei/v1 API calls and
 * posts them back to the content script via window.postMessage.
 */
(function () {
  'use strict';

  const CAPTURE_PATTERNS = [
    // Channel-level analytics (Overview tab)
    { pattern: '/youtubei/v1/analytics_data/join', type: 'channel_analytics' },
    // Per-video analytics (Content tab, individual video detail)
    { pattern: '/youtubei/v1/analytics_data/query', type: 'video_analytics' },
    // Channel metadata + video list
    { pattern: '/youtubei/v1/creator/list_creator_videos', type: 'video_list' },
    // Retention data (engagement tab per video)
    { pattern: '/youtubei/v1/analytics_data/get_screen', type: 'screen_data' },
  ];

  function matchPattern(url) {
    for (const p of CAPTURE_PATTERNS) {
      if (url.includes(p.pattern)) return p;
    }
    return null;
  }

  // --- Intercept fetch() ---
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await originalFetch.apply(this, args);
    const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
    const match = matchPattern(url);

    if (match) {
      try {
        // Clone so the original consumer still gets the body
        const clone = response.clone();
        const body = await clone.json();
        window.postMessage({
          source: 'vidiq-coach-capture',
          type: match.type,
          url: url,
          data: body,
          capturedAt: new Date().toISOString()
        }, '*');
      } catch (e) {
        // Silently skip non-JSON or failed reads
      }
    }

    return response;
  };

  // --- Intercept XMLHttpRequest ---
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._vidiqUrl = url;
    this._vidiqMatch = matchPattern(url);
    return originalXHROpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    if (this._vidiqMatch) {
      this.addEventListener('load', function () {
        try {
          const body = JSON.parse(this.responseText);
          window.postMessage({
            source: 'vidiq-coach-capture',
            type: this._vidiqMatch.type,
            url: this._vidiqUrl,
            data: body,
            capturedAt: new Date().toISOString()
          }, '*');
        } catch (e) {
          // Skip
        }
      });
    }
    return originalXHRSend.apply(this, args);
  };

  console.log('[vidIQ Coach Capture] Network interceptor active');
})();
